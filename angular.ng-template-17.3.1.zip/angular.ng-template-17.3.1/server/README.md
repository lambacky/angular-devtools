# @angular/language-server

This package contains the Language Server Protocol ([LSP](https://microsoft.github.io/language-server-protocol/)) implementation of the Angular Language Service.

## Usage
See `node index.js --help`
